#!/usr/bin/python3

from collections import defaultdict
from heapq import nlargest
import sys


movie_arr = {}
ratings_arr = {}
top_movie = {}

for line in sys.stdin:
	line = line.strip()
	line = line.split("\t")
	if len(line) == 3:
		movie_id=line[0]
		movie_title=line[1]
		if movie_id in movie_arr:
			movie_arr[movie_id].append(str(movie_title))
		else:
			movie_arr[movie_id] = []
			movie_arr[movie_id].append(str(movie_title))
	else:
		movie_id2=line[0]
		ratings=line[1]	
		if movie_id2 in ratings_arr:
			ratings_arr[movie_id2].append(float(ratings))
		else:
			ratings_arr[movie_id2] = []
			ratings_arr[movie_id2].append(float(ratings))
d = {}
for key in set(list(movie_arr.keys()) + (list(ratings_arr.keys()))):
	try:
		d.setdefault(key,[]).append(movie_arr[key])
	except KeyError:
		pass
	try:
		d.setdefault(key,[]).append(ratings_arr[key])
	except KeyError:
		pass
#Reduce
for movie in d.keys():
	if len(d[movie]) == 2:
		ave_rating = sum(d[movie][1])*1.0 / len(d[movie][1])
	
		top_movie[(d[movie])[0][0]] = ave_rating
top = nlargest(5, top_movie, key = top_movie.get)
print("Movie_Name , Rating")
for movie in top:
	print(movie,top_movie.get(movie))
