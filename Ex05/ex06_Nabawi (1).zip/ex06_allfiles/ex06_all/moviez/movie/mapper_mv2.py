#!/usr/bin/python3
import sys


for line in sys.stdin:
    line = line.strip()
    line = line.split("::")
    user = int(line[0])
    rating = float(line[2])
    print(f'{user}\t{rating}')
