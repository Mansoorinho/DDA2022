#!/usr/bin/python3

import sys

for line in sys.stdin:
	line = line.strip()
	line = line.split("::")
	if len(line) == 3:
		movie_id=line[0]
		movie_title=line[1]
		movie_genre=line[2]
		print ('%s\t%s\t%s' % (movie_id, movie_title,movie_genre))
	else:
		movie_id=line[1]
		ratings=line[2]
		print ('%s\t%s' % (movie_id, ratings))
