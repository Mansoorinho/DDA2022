#!/usr/bin/python3
import sys

cumulative_rating = 0
current_user = None

lowest_average = 5
user_id_lowest = None

for line in sys.stdin:
    user, rating = line.split("\t")
    user = int(user)
    rating = float(rating)
    if current_user == user:
        count_ratings +=1
        cumulative_rating +=rating
    else:
        if current_user is not None:
            if count_ratings>40:
                current_average  = cumulative_rating/count_ratings
                if current_average<lowest_average:
                    lowest_average= current_average
                    user_id_lowest = current_user
        count_ratings = 1
        cumulative_rating = rating
        current_user = user

if count_ratings>40:
    current_average  = cumulative_rating/count_ratings
    if current_average<lowest_average:
        lowest_average= current_average
        user_id_lowest = current_user

print(f'{user_id_lowest}\t{lowest_average:.04f}')
