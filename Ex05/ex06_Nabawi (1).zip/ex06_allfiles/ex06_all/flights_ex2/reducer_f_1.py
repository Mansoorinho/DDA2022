#!/usr/bin/python3

# import sys because we need to read and write data to STDIN and STDOUT
import sys

airport_delay = {}

#reading the output of the mapper.
#going through each line
for line in sys.stdin:
	line = line.strip()
	line = line.split("\t")

	if len(line) > 1:
		dep_airport = line[0]
		dep_delay = line[1]
	else:
		dep_airport = line[0]
		dep_delay = 0.0

	if dep_airport in airport_delay:

		airport_delay[dep_airport].append(float(dep_delay))
	else:
		airport_delay[dep_airport] = []
		airport_delay[dep_airport].append(float(dep_delay))

print("Airport | Maximum_departure_delay | Minimum_departure_delay | Average_departure_delay")
#reduce
#going through each origin and find the max, min, and average
for origin in airport_delay.keys():

	max_dep_delay = max(airport_delay[origin])*1.0
	min_dep_delay = min(airport_delay[origin])*1.0
	avg_dep_delay = sum(airport_delay[origin])*1.0 / len(airport_delay[origin])
	print('%s\t%s\t%s\t%s'% (origin, max_dep_delay, min_dep_delay, round(avg_dep_delay)))
