#!/usr/bin/python3

# import sys because we need to read and write data to STDIN and STDOUT
import sys
from heapq import nlargest

airport_delay = {}
N=10
#reading the output of the mapper.
#going through each line
for line in sys.stdin:
	line = line.strip()
	line = line.split("\t")

	if len(line) > 1:
		destination = line[0]
		arr_delay = line[1]
	else:
		destination = line[0]
		arr_delay = 0.0

	if destination in airport_delay:

		airport_delay[destination].append(float(arr_delay))
	else:
		airport_delay[destination] = []
		airport_delay[destination].append(float(arr_delay))

#reduce
for destination in airport_delay.keys():
	ave_arr_delay = sum(airport_delay[destination])*1.0 / len(airport_delay[destination])
	airport_delay[destination] = ave_arr_delay

top10_ave_arr_delay = nlargest(N, airport_delay, key = airport_delay.get)

print("Top 10 airports by their average arrival delay:")
print("Keys , Values")

for airport in top10_ave_arr_delay:
	print(airport,airport_delay.get(airport))
