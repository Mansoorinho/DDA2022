#!/usr/bin/python3

# import sys because we need to read and write data to STDIN and STDOUT
import sys
df = sys.stdin
#skipping the first row as it is column names
next(df)
#reading each line of the dataset.
for line in sys.stdin:
	line = line.strip()
	line = line.split(",")

	if len(line) >=2:
		destination = line[4]
		arr_delay = line[8]

		print("%s\t%s" % (destination, arr_delay))
