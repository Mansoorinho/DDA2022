#!/usr/bin/python3

# import sys because we need to read and write data to STDIN and STDOUT
import sys
df = sys.stdin
#skipping the first row as it is column names
next(df)
#reading each line of the dataset.
for line in sys.stdin:
	line = line.strip()
	line = line.split(",")

	if len(line) >=2:
		dep_airport = line[3]
		dep_delay = line[6]

		print("%s\t%s" % (dep_airport, dep_delay))
