
from mpi4py import MPI
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from sklearn import metrics as mt
import glob
import time
import gc



def load_data_kdd(data = "kdd_final_filtered.csv"):
    #freeing up the memory 
    gc.collect()
    #reading the saved dataset
    kdd = pd.read_csv(data, low_memory=False)
    #target
    y = kdd["TARGET_D"].to_numpy()
    x = kdd.drop(columns=["TARGET_D"], axis=1)
 
    bias = pd.DataFrame(np.ones(x.shape[0]).reshape(-1,1), columns = ["bias"])
    x = pd.concat([bias, x], axis=1).to_numpy()
    
    return x, y

def train_test_split(data ,frac=0.7):
    data = pd.DataFrame(data)
    #train_test split
    train = data.sample(frac=frac, random_state=10)
    test = data.drop(train.index)
    
    return train.to_numpy(), test.to_numpy()

def normalize_rows(x: np.ndarray):
    return x/np.linalg.norm(x, ord=2, axis=1, keepdims=True)

print('Loading data...', flush=True)
x,y = load_data_kdd()
print(f"X shape: {x.shape}")
x = normalize_rows(x)
print('Splitting into train and test sets...', flush=True)
x_train, x_test = train_test_split(x ,frac=0.7)
y_train, y_test = train_test_split(y ,frac=0.7)

data = np.concatenate((y_train, x_train), axis=1)
#Initializing weights = 0
# w = np.zeros((1,480), dtype=float)
np.random.seed(2021)
weights = np.random.randint(0,5,size=((1,261)))

#learning rate
lr = 0.00001

#Setting the number of epochs
N = 100
train_loss_kdd = [] 
test_loss_kdd = [] 

converged = False #For checking convergence 
j = 0


t0 = MPI.Wtime()
arrow = y_train.shape[0]

#Training for N Epochs
while (not converged) and (j < N):
    if j%10==0:
        print("Epoch : ", j, flush=True)

    yy = np.zeros((arrow,1))
    closs = 0
    #Shuffling the received dataset at each worker
    np.take(data,np.random.permutation(data.shape[0]),axis=0,out=data)
    #Epoch
    for i in range(0, arrow):
        xt = data[i,1:]
        yt = data[i,0]    
        #Forward pass
        yy[i,0] = np.matmul(xt, weights.T)
        #Backpropagation
        #Computing Derivatives
        derv_lossyy = -2*(yt - yy[i,0])
        derv_yyw = xt
        #Computing Derivatives using Chain Rule
        derv_lossw = derv_lossyy * derv_yyw 

        #Computing new weights    
        weights = weights - lr * derv_lossw
    

    tloss = np.sqrt(mt.mean_squared_error(data[:,0], yy[:,0]))
    train_loss_kdd.append(tloss)

    #Evaluating the model
    z = np.matmul(x_test, weights.T)
    #Computing RME Testing
    vloss = np.sqrt(mt.mean_squared_error(y_test, z))
    test_loss_kdd.append(vloss)    

    #Checking for convergence if the change in RMSE testing is less than 10^-6
    if j > 0 and abs((test_loss_kdd[j-1] - test_loss_kdd[j])) < 10**-6:
        print(test_loss_kdd[j-1]- test_loss_kdd[j], flush=True)
        converged = True

    j += 1
    
print("No of iterations = ", j, flush=True)
print("Training RMSE = ", train_loss_kdd[j-1], flush=True)
print("Min Training RMSE = ", np.min(train_loss_kdd), flush=True)
print("Testing RMSE = ", test_loss_kdd[j-1], flush=True)
print("Min Testing RMSE = ", np.min(test_loss_kdd), flush=True)
#Ending time    
time_end = MPI.Wtime()
time_taken = time_end - t0
print("Time elapsed for serial code:", time_taken)
