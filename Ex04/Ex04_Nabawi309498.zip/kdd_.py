
from mpi4py import MPI
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from sklearn import metrics as mt
import glob
import gc
rng = np.random.default_rng(2021)

#Initializing MPI
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

##-------------Function Definition--------

#reading dataset
def load_data_kdd(data = "kdd_final_filtered.csv"):
    #freeing up the memory 
    gc.collect()
    #reading the saved dataset
    kdd = pd.read_csv(data, low_memory=False)
    #target
    y = kdd["TARGET_D"].to_numpy()
    x = kdd.drop(columns=["TARGET_D"], axis=1)
 
    bias = pd.DataFrame(np.ones(x.shape[0]).reshape(-1,1), columns = ["bias"])
    x = pd.concat([bias, x], axis=1).to_numpy()
    
    return x, y

#splitting dataset
def train_test_split(data ,frac=0.7):
    data = pd.DataFrame(data)
    #train_test split
    train = data.sample(frac=frac, random_state=10)
    test = data.drop(train.index)
    
    return train.to_numpy(), test.to_numpy()

#normalzining based on rows
def row_normalizer(x: np.ndarray):
    return x/np.linalg.norm(x, ord=2, axis=1, keepdims=True)

#prediciton
def predict(x, betas):
    return np.matmul(x, betas.T)

#SGD function
def sgd(x, weight, y, y_hat, lr):
    
    #Computing Derivatives using Chain Rule
    dv_loss = x * (-2*(y - y_hat) )
    #Computing new weights    
    weight = weight - lr * dv_loss
    
    return weight
#calculate_RMSE
def calculate_RMSE(true_y, pred_y):
    return np.sqrt(mt.mean_squared_error(true_y, pred_y))


##----------End of function definition---------

#Master node
if rank == 0:
    print('Loading data...', flush=True)
    x,y = load_data_kdd()
    print(f"X shape: {x.shape}")
    #print("Normalizing")

    x = row_normalizer(x)
    
    print('Splitting into train and test sets...', flush=True)
    x_train, x_test = train_test_split(x ,frac=0.7)
    y_train, y_test = train_test_split(y ,frac=0.7)

    data = np.concatenate((y_train.reshape(-1,1), x_train), axis=1)

    
#fixing seed
np.random.seed(2021)
#random weights
w = np.random.randint(0,5,size=((1,261)))

#learning rate
lr = 0.00001

#Setting the number of epochs
N = 100
train_loss = [] 
test_loss = [] 

converged = False #For checking convergence 
epoch = 0

if rank == 0:
    #Starting time
    t0 = MPI.Wtime()
        
#Training for N Epochs
while (not converged) and (epoch < N):
            
    if rank == 0:
        #print onlt every 10 steps
        if epoch%10==0:
            print("Epoch : ", epoch, flush=True)

        #splitting      
        data_part = np.array_split(data,size)
    else:
        data_part = None
    #Sending data using scatter and weights via bcast
    recvd_dt = comm.scatter(data_part,root=0)
    weights = comm.bcast(w,root=0)
    row_, col_ = np.shape(recvd_dt)
    y_hat = np.zeros((row_,1))
    
    #Shuffling the received dataset at each worker
    np.take(recvd_dt,np.random.permutation(recvd_dt.shape[0]),axis=0,out=recvd_dt)
    #Epoch
    for i in range(0, row_):
        X_part = recvd_dt[i,1:]
        y_part = recvd_dt[i,0]    
        #Prediction of instance i, forward pass
        y_hat[i,0] = predict(X_part, weights.T)

        #Computing new weights    
        weights = sgd(X_part, weights, y_part, y_hat[i,0], lr)
    
    #Gathering weights at Worker 0
    w_r = comm.gather(weights, root=0)
    #Gathering predicted output (yy) and original data (true_dt) at Worker 0
    y_hat_recvd = comm.gather(y_hat, root=0)
    true_dt = comm.gather(recvd_dt[:,0], root=0)

    if rank == 0 and converged == False:
        #Worker 0 computing mean of the weights
        w = np.mean(w_r, axis=0)
        
        pred_y = np.vstack(y_hat_recvd)
        true_y = np.hstack(true_dt)

        #Worker 0 computing calculate_RMSE
        calculate_RMSE_train = calculate_RMSE(true_y, pred_y)
        train_loss.append(calculate_RMSE_train)
    
        #test prediction
        pred_y_test = predict(x_test, w.T)
        #Computing RME Testing
        calculate_RMSE_test = calculate_RMSE(y_test, pred_y_test)
        test_loss.append(calculate_RMSE_test)    

        #Checking for convergence in RMSE test
        if epoch > 0 and abs((test_loss[epoch-1] - test_loss[epoch])) < 10**-6:
            print(test_loss[epoch-1]- test_loss[epoch], flush=True)
            converged = True
    #the converged flag is sent back for stopping epochs
    converged = comm.bcast(converged,root=0)
    epoch += 1

if rank == 0:
    #End time
    t1 = MPI.Wtime()
    df = pd.DataFrame(list(zip(train_loss, test_loss)),columns =['train_loss', 'test_loss'])
    df.to_csv(f"loss{size}.csv", index=False)
    #t1 = MPI.Wtime()
    time_final = t1 - t0
    print("With P = {} Workers, the process took {} seconds" .format(size, time_final), flush=True)
