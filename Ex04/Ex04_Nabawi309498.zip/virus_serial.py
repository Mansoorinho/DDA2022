
from mpi4py import MPI
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from sklearn import metrics as mt
import glob
import time



def load_virus():
    #freeing up the memory 
    gc.collect()
    path = 'dataset/dataset/'
    files = os.listdir(path)
    li = []
    for filename in files:
        df = pd.read_csv(path+filename, header=None)
        li.append(df)

    dat_file = pd.concat(li, axis=0, ignore_index=True)

    y = np.zeros((107856,1), float)
    x = np.zeros((107856,479))
    for i in dat_file.index:
        doc = dat_file.iloc[i][0].strip().split()
        y[i] = float(doc[0])

        for element in doc[1:]:
            k, v = element.split(":")
            x[i,int(k)] = int(v)
    bias = np.ones((107856,1))
    x = np.append(bias, x, axis=1)
            
    return x,y 

def train_test_split(data ,frac=0.7):
    data = pd.DataFrame(data)
    #train_test split
    train = data.sample(frac=frac, random_state=10)
    test = data.drop(train.index)
    
    return train.to_numpy(), test.to_numpy()

def normalize_rows(x: np.ndarray):
    return x/np.linalg.norm(x, ord=2, axis=1, keepdims=True)

print('Loading data...', flush=True)
x,y = load_virus()
print(f"X shape: {x.shape}")
x = normalize_rows(x)
print('Splitting into train and test sets...', flush=True)
x_train, x_test = train_test_split(x ,frac=0.7)
y_train, y_test = train_test_split(y ,frac=0.7)

data = np.concatenate((y_train, x_train), axis=1)
#Initializing weights = 0
# w = np.zeros((1,480), dtype=float)
weights = np.random.randint(0,2,size=((1,480)))

#learning rate
lr = 0.00001

#Setting the number of epochs
N = 100
train_loss = [] 
test_loss = [] 

converged = False #For checking convergence 
j = 0


t0 = MPI.Wtime()
arrow = y_train.shape[0]

#Training for N Epochs
while (not converged) and (j < N):
    if j%10==0:
        print("Epoch : ", j, flush=True)

    yy = np.zeros((arrow,1))
    closs = 0
    #Shuffling the received dataset at each worker
    np.take(data,np.random.permutation(data.shape[0]),axis=0,out=data)
    #Epoch
    for i in range(0, arrow):
        xt = data[i,1:]
        yt = data[i,0]    
        #Forward pass
        yy[i,0] = np.matmul(xt, weights.T)
        #Backpropagation
        #Computing Derivatives
        dv = -2*(yt - yy[i,0])
        
        #Computing Derivatives using Chain Rule
        derv_lossw = xt * dv 

        #Computing new weights    
        weights = weights - lr * derv_lossw
    

    tloss = np.sqrt(mt.mean_squared_error(data[:,0], yy[:,0]))
    train_loss.append(tloss)

    #Evaluating the model
    z = np.matmul(x_test, weights.T)
    #Computing RME Testing
    vloss = np.sqrt(mt.mean_squared_error(y_test, z))
    test_loss.append(vloss)    

    #Checking for convergence if the change in RMSE testing is less than 10^-6
    if j > 0 and abs((test_loss[j-1] - test_loss[j])) < 10**-6:
        print(test_loss[j-1]- test_loss[j], flush=True)
        converged = True

    j += 1
    
print("No of iterations = ", j, flush=True)
print("Training RMSE = ", train_loss[j-1], flush=True)
print("Min Training RMSE = ", np.min(train_loss), flush=True)
print("Testing RMSE = ", test_loss[j-1], flush=True)
print("Min Testing RMSE = ", np.min(test_loss), flush=True)
#Ending time    
time_end = MPI.Wtime()
time_taken = time_end - t0
print("Time elapsed for serial code:", time_taken)
